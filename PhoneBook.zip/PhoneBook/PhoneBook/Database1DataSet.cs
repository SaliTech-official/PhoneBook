﻿namespace PhoneBook
{


    partial class Database1DataSet
    {
    }
}

namespace PhoneBook.Database1DataSetTableAdapters {
    
    
    public partial class PhonesTableAdapter {
    }
}
